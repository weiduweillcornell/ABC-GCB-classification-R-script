library(gplots)
library(ggplot2)
setwd("~/Desktop/Pathway_Analysis/ABC_GCB_classifier/")
n<-100 #top n differentially expressed genes to be used in the predictor

################################################################################################
rank.normalization<-function(matrix)
{
  n<-dim(matrix)[2]
  rank.norm<-t(apply(matrix,1,rank))/n
  return(rank.norm)
}

p.subgroup<-function(pred,ABC.pred,GCB.pred)
{
  #  pred<-ABC.pred
  mean.ABC<-mean(ABC.pred)
  sd.ABC<-sd(ABC.pred)
  mean.GCB<-mean(GCB.pred)
  sd.GCB<-sd(GCB.pred)
  p.ABC<-dnorm(pred,mean.ABC,sd.ABC)/(dnorm(pred,mean.ABC,sd.ABC)+dnorm(pred,mean.GCB,sd.GCB))
  p.GCB<-1-p.ABC  
  p<-rbind(p.ABC,p.GCB)
  rownames(p)<-c("p.ABC","p.GCB")
  return(p)
}
##################################################################################################

## loading labeled microarray 
staudt<-read.table("staudt_dlbcl_pnas_2008.txt",row.names=1,sep="\t",header=T)
label<-read.table("staudt_dlbcl_pnas_2008.GCB_ABC_labels.txt",row.names=1,sep="\t",header=F)
colnames(staudt)<-substr(colnames(staudt),nchar(colnames(staudt))-11,nchar(colnames(staudt)))
rownames(label)<-substr(rownames(label),nchar(rownames(label))-11,nchar(rownames(label)))

## rank normalization of microarray
staudt.rank<-rank.normalization(staudt)

## divide train and test set
ABC.rank<-staudt.rank[,label=="ABC "]
ABC.train<-ABC.rank[,1:37]
ABC.test<-ABC.rank[,38:74]
GCB.rank<-staudt.rank[,label=="GCB "]
GCB.train<-GCB.rank[,1:36]
GCB.test<-GCB.rank[,37:71]

p.value.rank<-vector()
t.statistic.rank<-vector()
## select predictors
for(i in 1:dim(ABC.train)[1])
{
  t.test.result<-t.test(ABC.train[i,],GCB.train[i,])
  p.value.rank[i]<-t.test.result$p.value 
  t.statistic.rank[i]<-t.test.result$statistic 
}
names(p.value.rank)<-rownames(ABC.train)
names(t.statistic.rank)<-rownames(ABC.train)
FDR<-p.adjust(p.value.rank,"BH")
t.statistic<-t.statistic.rank[rank(FDR)<=n]
ABC.pred<-t.statistic %*% ABC.train[rank(FDR)<=n,]
GCB.pred<-t.statistic %*% GCB.train[rank(FDR)<=n,]

## validate on train and test set
ABC.test.LPS<-t.statistic %*% ABC.test[rank(FDR)<=n,]
GCB.test.LPS<-t.statistic %*% GCB.test[rank(FDR)<=n,]
p.ABC.train<-p.subgroup(ABC.pred,ABC.pred,GCB.pred)
p.GCB.train<-p.subgroup(GCB.pred,ABC.pred,GCB.pred)
p.ABC.test<-p.subgroup(ABC.test.LPS,ABC.pred,GCB.pred)
p.GCB.test<-p.subgroup(GCB.test.LPS,ABC.pred,GCB.pred)

## load RNA-seq data (Please modify this part to accomodate with your dataset)
file<-read.table("FPKMcombined.csv",sep="," ,row.names=1, header=T)
file<-file[!duplicated(file[,1]),]
DLBCL_patient<-file[,grepl("dbGaP.SRS",colnames(file))]
DLBCL_cellline<-file[,grepl("cellLines.Sample",colnames(file))]
DLBCL<-cbind(DLBCL_patient,DLBCL_cellline)
row.names(DLBCL)<-file[,1]

## prepare predictors
pred<-names(FDR[rank(FDR)<=n])[names(FDR[rank(FDR)<=n]) %in% rownames(DLBCL)]
DLBCL.pred<-rank.normalization(DLBCL[pred,])
DLBCL.LPS<-t.statistic[pred] %*% DLBCL.pred
ABC.pred.test<-t.statistic[pred] %*% ABC.train[pred,]
GCB.pred.test<-t.statistic[pred] %*% GCB.train[pred,]

test.subgroup<-p.subgroup(DLBCL.LPS,ABC.pred.test,GCB.pred.test)
sort.DLBCL<-sort(test.subgroup[1,],decreasing=T)
DLBCL.pred[,names(sort.DLBCL)]
pdf(paste0(getwd(),"/sort-heatmap.pdf"))
heatmap.2(as.matrix(DLBCL.pred[,names(sort.DLBCL)]),Colv=F,col=redgreen(75),scale="row",key=T, keysize=1.5,density.info="none", trace="none",cexCol=0.3,cexRow=0.3)
dev.off()

pdf(paste0(getwd(),"/probability-plot.pdf"),7,4)
plot(sort.DLBCL,axes=F,type="n",xlab="",ylab="p")
axis(1,labels=F)
axis(2)
lines(sort.DLBCL,col="dark red",lwd=3)
lines(1-sort.DLBCL,col="dark blue",lwd=3)
abline(h=0.9,lty=3,col="grey",lwd=3)
legend("right",legend=c("ABC Probability","GCB Probability"),col=c("dark red","dark blue"),lwd=c(3,3),cex=0.8)
dev.off()

list<-c(rep("unclassified",dim(DLBCL)[2]))
list[test.subgroup[1,]>0.9]<-"ABC"
list[test.subgroup[2,]>0.9]<-"GCB"
names(list)<-colnames(test.subgroup)
write.table(list,file=paste0(getwd(),"/classification-label.txt"),sep="\t",col.names=F)